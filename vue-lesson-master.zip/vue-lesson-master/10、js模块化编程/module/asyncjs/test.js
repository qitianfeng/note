console.log('i am test js')

function outputLog(arg) {
	console.log(arg)
}