var name = customModule.getName() ;
console.log(name)


var time = customModule2.getTime() ;
console.log(time)


var myrunMdule = runMdule
console.log(myrunMdule.getMyName())


console.log(window.module.getName +":"+window.module.age)




