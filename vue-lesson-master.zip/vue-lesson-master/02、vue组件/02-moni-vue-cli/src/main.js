import Vue from 'vue' ;
import first from './first'

new Vue({
  el: '#container',
  render:h => h(first)
})
