> 本 demo 的运行步骤

* 1、git clone https://github.com/githubchen001/vue-lesson
* 2、cd 02、vue组件/02-moni-vue-cli
* 3、执行 yarn install 安装依赖
* 4、命令持输入 yarn start 显示效果
