import Vue from 'vue';
import { Button,Actionsheet } from 'mint-ui';

Vue.component(Button.name, Button);
Vue.component(Actionsheet.name, Actionsheet);
